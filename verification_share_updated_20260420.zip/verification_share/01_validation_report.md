# Phase 1 계산 검증 리포트
생성일: 2026-04-20 17:33
커밋 해시: N/A

## 1. 핵심 지표 요약

| 지표 | 값 | 비고 |
|---|---|---|
| WMAPE (공식) | 25.2% | sigma-abs(err)/sigma(actual) |
| MAPE (표준) | 35.0% | mean(abs(err)/actual) |
| 검증 주차 | 29주 | 5-fold CV 유효 주차 |
| 총 실측 수확량 | 10.2 kg/m² | 전 작기 누적 |

## 2. 단계별 오차율 (WMAPE / MAPE 병기)

| 단계 | WMAPE | MAPE | 비고 |
|---|---|---|---|
| TOMGRO 단독 | 25.6% | 30.3% | 물리 모델 |
| + S&V (시차 7주) | 35.5% | 35.9% | EC 스트레스 |
| + XGBoost CV | 25.2% | 35.0% | 5-fold 선형 |

## 3. 파라미터 검증

| 파라미터 | 기대값 | 실제 사용값 | 상태 |
|---|---|---|---|
| LEAF_SHAPE_FACTOR | 0.5 | 0.5 | ✓ |
| PLANTING_DENSITY | 2.78 | 2.78 | ✓ |
| LIGHT_TRANSMISSION | 0.50 | 0.5 | ✓ |
| FRUIT_DM_CONTENT | 0.07 | 0.07 | ✓ |
| EC_THRESHOLD | 2.5 | 2.5 | ✓ |
| YIELD_SLOPE | 0.09 | 0.09 | ✓ |
| TOMGRO_HARVEST_LAG | 8주 | 8주 | ✓ |
| SV_EC_LAG_BEFORE_HARVEST | 1주 (시차 7) | 7주 | ✓ |

## 4. 핵심 수치 스팟 체크

### Scene 1 (2025-11-12)
- TOMGRO: 0.400 kg/m², LAI: 3.030, S&V EC: 7.69 dS/m, yield: 0.213
- 최종 예측: 0.314 kg/m²
- 실측 수확량: 0.393 kg/m²
- 오차율: 20.2%
- 상태: ✓

### 전 작기 통계
- 기대: WMAPE 25.2% (±1%)
- 실측: 25.2%
- 상태: ✓

## 5. 발견 사항 / 이슈

- **WMAPE vs MAPE 괴리**: 스펙이 WMAPE(25.2%)를 공식 지표로 사용. MAPE 기준으로는 35.0%로 ~9.8%p 높음. 초기 생육기(7~8월) 소수확 주차의 큰 오차율이 MAPE를 과대 계상.
- **step6 명칭 주의**: 파일명은 `step6_xgboost_cv.py`지만 현재는 `LinearRegression` 사용 (데이터 29주, XGBoost 과적합 우려). Phase 2에서 데이터 누적 후 XGBoost 교체 예정.
- **Scene 2 고오차 (144.5%)**: 2025-08-13 초기 생육기. 실측 0.103 kg/m² 대비 예측 0.253 — 정식 초기 과실 착과량이 극히 적어 어느 모델이든 과예측 경향.
- **LEAF_SHAPE_FACTOR 0.5**: 표준 Heuvelink(1995) 권장값 0.7 대비 하향 조정. 박현도 재배사 토마지노(방울토마토) 실측 교정값으로, Phase 2 직접 엽면적 측정으로 재확인 필요.
- **LIGHT_TRANSMISSION 50%**: 센서 위치(작업로 측벽) 보정으로 설정. Phase 2 PAR 센서 캐노피 위 설치 후 실측 예정.

---

## Phase 1.5 업데이트 (2026-04-20)

| 변경 항목 | Phase 1 | Phase 1.5 |
|---|---|---|
| S&V 시차 | 수확 1주 전 (착색기) | 수확 7주 전 (착과기) |
| 최종 WMAPE | 25.2% | **21.7%** |
| Scene 1 오차율 | 20.2% | **3.9%** |
| Scene 3 오차율 | 9.0% | **2.8%** |

**변경 근거**: EC 심층 분석 (verification_share_v2) 가설 B 성립.
착과기(수확 7주 전) EC가 수확량을 결정하며, 수확 직전 EC는 당도 결정.

**상세**: `farm_ai_phase1/PHASE_1.5_UPDATE.md` 참조
